// lib/src/core/theme/app_spacing.dart

abstract final class AppSpacing {
  const AppSpacing._();

  static const double x4 = 4;
  static const double x8 = 8;
  static const double x10 = 10;
  static const double x12 = 12;
  static const double x14 = 14;
  static const double x16 = 16;
  static const double x20 = 20;
  static const double x24 = 24;
  static const double x30 = 30;
  static const double x40 = 40;
  static const double x50 = 50;
  static const double x60 = 60;
  static const double x70 = 70;
}
