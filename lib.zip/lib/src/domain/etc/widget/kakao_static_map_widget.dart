import 'dart:math' as math;

import 'package:beatit_front_app/src/core/extensions/app_theme_extension.dart';
import 'package:beatit_front_app/src/core/theme/app_fonts.dart';
import 'package:flutter/material.dart';

const String _kakaoRestApiKey = String.fromEnvironment('KAKAO_REST_API_KEY');

class KakaoStaticMapWidget extends StatelessWidget {
  const KakaoStaticMapWidget({
    super.key,
    required this.latitude,
    required this.longitude,
    this.height,
    this.level = 4,
    this.borderRadius = BorderRadius.zero,
    this.onTap,
  });

  final double latitude;
  final double longitude;
  final double? height;
  final int level;
  final BorderRadius borderRadius;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final child = ClipRRect(
      borderRadius: borderRadius,
      child: LayoutBuilder(
        builder: (context, constraints) {
          if (_kakaoRestApiKey.trim().isEmpty) {
            return _MapFallback(
              height: height,
              message: '카카오 지도 키가 설정되지 않았습니다.',
            );
          }

          final devicePixelRatio = MediaQuery.devicePixelRatioOf(context);
          final logicalWidth = constraints.maxWidth.isFinite
              ? constraints.maxWidth
              : 512.0;
          final logicalHeight = height ??
              (constraints.maxHeight.isFinite ? constraints.maxHeight : 210.0);

          final requestWidth = math.min(
            2048,
            math.max(1, (logicalWidth * devicePixelRatio).round()),
          );
          final requestHeight = math.min(
            1024,
            math.max(1, (logicalHeight * devicePixelRatio).round()),
          );

          final uri = Uri.https(
            'dapi.kakao.com',
            '/v2/maps/staticmap',
            <String, String>{
              'center': '$longitude,$latitude',
              'size': '${requestWidth}x$requestHeight',
              'lv': '$level',
            },
          );

          final map = Image.network(
            uri.toString(),
            headers: const <String, String>{
              'Authorization': 'KakaoAK $_kakaoRestApiKey',
            },
            width: double.infinity,
            height: height,
            fit: BoxFit.cover,
            gaplessPlayback: true,
            loadingBuilder: (context, child, progress) {
              if (progress == null) {
                return child;
              }

              return Container(
                width: double.infinity,
                height: height,
                color: context.grays.gray8,
                alignment: Alignment.center,
                child: const CircularProgressIndicator(),
              );
            },
            errorBuilder: (_, __, ___) {
              return _MapFallback(
                height: height,
                message: '지도를 불러오지 못했습니다.',
              );
            },
          );

          return SizedBox(
            width: double.infinity,
            height: height,
            child: Stack(
              fit: StackFit.expand,
              children: [
                map,
                IgnorePointer(
                  child: Center(
                    child: Transform.translate(
                      offset: const Offset(0, -18),
                      child: Icon(
                        Icons.location_on,
                        size: 44,
                        color: context.brands.beatOrange2,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );

    if (onTap == null) {
      return child;
    }

    return Material(
      color: Colors.transparent,
      child: InkWell(onTap: onTap, child: child),
    );
  }
}

class _MapFallback extends StatelessWidget {
  const _MapFallback({required this.height, required this.message});

  final double? height;
  final String message;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: height,
      color: context.grays.gray8,
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Text(
        message,
        textAlign: TextAlign.center,
        style: FontStyles.med14.copyWith(color: context.grays.gray5),
      ),
    );
  }
}
