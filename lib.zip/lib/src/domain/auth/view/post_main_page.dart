import 'package:beatit_front_app/src/core/extensions/app_theme_extension.dart';
import 'package:beatit_front_app/src/core/theme/app_fonts.dart';
import 'package:beatit_front_app/src/core/theme/app_spacing.dart';
import 'package:beatit_front_app/src/core/widgets/appbars/app_two_appbar.dart';
import 'package:beatit_front_app/src/core/widgets/dropdowns/app_dropdown_list.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

const String _goodIconPath = 'assets/icons/post/good.svg';
const String _chatIconPath = 'assets/icons/post/chat.svg';

enum PostMainType { notice, poll, meetit }

extension PostMainTypeExtension on PostMainType {
  String get title {
    switch (this) {
      case PostMainType.notice:
        return '공지';
      case PostMainType.poll:
        return '투표';
      case PostMainType.meetit:
        return '밋잇';
    }
  }

  String get createMenuLabel {
    switch (this) {
      case PostMainType.notice:
        return '공지 작성하기';
      case PostMainType.poll:
        return '투표 생성하기';
      case PostMainType.meetit:
        return '밋잇 생성하기';
    }
  }
}

class PostMainPage extends StatefulWidget {
  const PostMainPage({super.key});

  @override
  State<PostMainPage> createState() => _PostMainPageState();
}

class _PostMainPageState extends State<PostMainPage> {
  PostMainType _selectedType = PostMainType.notice;
  bool _isTypeMenuOpen = false;

  void _changePostType(PostMainType type) {
    if (_selectedType == type) {
      return;
    }

    setState(() {
      _selectedType = type;
    });
  }

  void _changeTypeMenuState(bool isOpen) {
    if (_isTypeMenuOpen == isOpen) {
      return;
    }

    setState(() {
      _isTypeMenuOpen = isOpen;
    });
  }

  void _handleCreatePressed() {
    switch (_selectedType) {
      case PostMainType.notice:
        // TODO: 공지 작성 페이지로 이동
        return;
      case PostMainType.poll:
        // TODO: 투표 생성 페이지로 이동
        return;
      case PostMainType.meetit:
        // TODO: 밋잇 생성 페이지로 이동
        return;
    }
  }

  Widget _buildSelectedContent() {
    switch (_selectedType) {
      case PostMainType.notice:
        return const _NoticeContent();
      case PostMainType.poll:
        return const _PollContent();
      case PostMainType.meetit:
        return const _MeetitContent();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppTwoAppBar(
        trailing: AppTwoAppBarTrailing.add,
        addMenuAlignment: AppDropdownAlignment.right,
        addMenuOffset: const Offset(0, 68),
        addMenuItems: [
          AppDropdownItem(
            label: _selectedType.createMenuLabel,
            onPressed: _handleCreatePressed,
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.x16,
            AppSpacing.x12,
            AppSpacing.x16,
            AppSpacing.x30,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _PostTypeDropdown(
                selectedType: _selectedType,
                isOpen: _isTypeMenuOpen,
                onChanged: _changePostType,
                onMenuStateChanged: _changeTypeMenuState,
              ),
              const SizedBox(height: AppSpacing.x24),
              AnimatedSize(
                duration: const Duration(milliseconds: 240),
                curve: Curves.easeOutCubic,
                alignment: Alignment.topCenter,
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 220),
                  switchOutCurve: Curves.easeInCubic,
                  switchInCurve: Curves.easeOutCubic,
                  transitionBuilder: (child, animation) {
                    final curvedAnimation = CurvedAnimation(
                      parent: animation,
                      curve: Curves.easeOutCubic,
                    );

                    return FadeTransition(
                      opacity: curvedAnimation,
                      child: SlideTransition(
                        position: Tween<Offset>(
                          begin: const Offset(0, 0.025),
                          end: Offset.zero,
                        ).animate(curvedAnimation),
                        child: child,
                      ),
                    );
                  },
                  child: KeyedSubtree(
                    key: ValueKey<PostMainType>(_selectedType),
                    child: _buildSelectedContent(),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _PostTypeDropdown extends StatelessWidget {
  const _PostTypeDropdown({
    required this.selectedType,
    required this.isOpen,
    required this.onChanged,
    required this.onMenuStateChanged,
  });

  final PostMainType selectedType;
  final bool isOpen;
  final ValueChanged<PostMainType> onChanged;
  final ValueChanged<bool> onMenuStateChanged;

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return MenuAnchor(
      alignmentOffset: const Offset(0, AppSpacing.x8),
      onOpen: () => onMenuStateChanged(true),
      onClose: () => onMenuStateChanged(false),
      style: MenuStyle(
        backgroundColor: MaterialStatePropertyAll<Color>(colorScheme.surface),
        elevation: const MaterialStatePropertyAll<double>(4),
        padding: const MaterialStatePropertyAll<EdgeInsetsGeometry>(
          EdgeInsets.symmetric(vertical: AppSpacing.x4),
        ),
        shape: MaterialStatePropertyAll<OutlinedBorder>(
          RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
            side: BorderSide(color: context.grays.gray7),
          ),
        ),
      ),
      menuChildren: PostMainType.values.map((type) {
        final isSelected = selectedType == type;

        return MenuItemButton(
          onPressed: () => onChanged(type),
          child: SizedBox(
            width: 120,
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    type.title,
                    style: FontStyles.med16.copyWith(
                      color: colorScheme.onSurface,
                    ),
                  ),
                ),
                if (isSelected)
                  Icon(Icons.check, size: 18, color: colorScheme.primary),
              ],
            ),
          ),
        );
      }).toList(),
      builder: (context, controller, child) {
        return Semantics(
          button: true,
          expanded: isOpen,
          label: '게시글 종류 선택',
          child: InkWell(
            borderRadius: BorderRadius.circular(5),
            onTap: () {
              if (controller.isOpen) {
                controller.close();
                return;
              }

              controller.open();
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: AppSpacing.x4),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 160),
                    child: Text(
                      selectedType.title,
                      key: ValueKey<PostMainType>(selectedType),
                      style: FontStyles.bold34.copyWith(
                        color: colorScheme.onSurface,
                      ),
                    ),
                  ),
                  const SizedBox(width: AppSpacing.x4),
                  AnimatedRotation(
                    turns: isOpen ? 0.5 : 0,
                    duration: const Duration(milliseconds: 180),
                    curve: Curves.easeOutCubic,
                    child: SvgPicture.asset(
                      'assets/icons/post/toggle_down.svg',
                      width: 24,
                      height: 24,
                      colorFilter: ColorFilter.mode(
                        colorScheme.onSurface,
                        BlendMode.srcIn,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

// -----------------------------------------------------------------------------
// 공지
// -----------------------------------------------------------------------------

class _NoticeContent extends StatelessWidget {
  const _NoticeContent();

  static const List<_NoticeData> _items = [
    _NoticeData(
      title: '[중요] 합주실 사용 공지',
      description: '안녕하세요. 합주실 사용과 관련하여 안내드립니다.',
      likeCount: 16,
      commentCount: 55,
      dateText: '2026.04.08 10:16 · 작성자 송하은',
      hasThumbnail: true,
    ),
    _NoticeData(
      title: '합주 일정 합류 공지',
      description: '잘 나가는 밴드 합주 일정은 다음과 같이 이루어집니다.',
      likeCount: 16,
      commentCount: 55,
      dateText: '2026.04.08 10:16 · 작성자 송하은',
      hasThumbnail: true,
    ),
    _NoticeData(
      title: '합주 일정 합류 공지',
      description: '잘 나가는 밴드 합주 일정은 방장의 투표 공지로 참여해주세요.',
      likeCount: 16,
      commentCount: 55,
      dateText: '2026.04.08 10:16 · 작성자 송하은',
      hasThumbnail: false,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: List.generate(_items.length, (index) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: index == _items.length - 1 ? 0 : AppSpacing.x20,
          ),
          child: _NoticeListItem(item: _items[index]),
        );
      }),
    );
  }
}

class _NoticeListItem extends StatelessWidget {
  const _NoticeListItem({required this.item});

  final _NoticeData item;

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                item.title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: FontStyles.bold20.copyWith(color: colorScheme.onSurface),
              ),
              const SizedBox(height: AppSpacing.x4),
              Text(
                item.description,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: FontStyles.med16.copyWith(color: context.grays.gray5),
              ),
              const SizedBox(height: AppSpacing.x8),
              _PostMetaChip(
                firstIconPath: _goodIconPath,
                firstText: '${item.likeCount}',
                secondIconPath: _chatIconPath,
                secondText: '${item.commentCount}',
              ),
              const SizedBox(height: AppSpacing.x8),
              Text(
                item.dateText,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: FontStyles.reg12.copyWith(color: context.grays.gray4),
              ),
            ],
          ),
        ),
        if (item.hasThumbnail) ...[
          const SizedBox(width: AppSpacing.x12),
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(5),
              color: context.grays.gray8,
            ),
          ),
        ],
      ],
    );
  }
}

class _NoticeData {
  const _NoticeData({
    required this.title,
    required this.description,
    required this.likeCount,
    required this.commentCount,
    required this.dateText,
    required this.hasThumbnail,
  });

  final String title;
  final String description;
  final int likeCount;
  final int commentCount;
  final String dateText;
  final bool hasThumbnail;
}

// -----------------------------------------------------------------------------
// 투표
// -----------------------------------------------------------------------------

class _PollContent extends StatelessWidget {
  const _PollContent();

  static const List<_PollData> _activePolls = [
    _PollData(
      title: '[중요] 4월 합주 일정 투표',
      dateText: '2026.04.08 10:16 종료 예정',
      participantCount: 7,
      voteStatus: '투표 완료',
      isUrgent: true,
    ),
    _PollData(
      title: '5월 합주 일정 투표',
      dateText: '2026.04.08 10:16 종료 예정',
      participantCount: 7,
      voteStatus: '투표 완료',
    ),
    _PollData(
      title: '6월 합주 일정 투표',
      dateText: '2026.04.08 10:16 종료 예정',
      participantCount: 7,
      voteStatus: '투표 안함',
    ),
  ];

  static const List<_PollData> _completedPolls = [
    _PollData(
      title: '2월 합주 일정 투표',
      dateText: '2026.04.08 10:16 종료된 투표',
      participantCount: 28,
      voteStatus: '투표 안함',
    ),
    _PollData(
      title: '1월 합주 일정 투표',
      dateText: '2026.04.08 10:16 종료된 투표',
      participantCount: 19,
      voteStatus: '투표 완료',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const _PollSection(
          title: '진행 중인 투표',
          items: _activePolls,
          isActive: true,
        ),
        const SizedBox(height: AppSpacing.x16),
        Divider(height: 1, thickness: 1, color: context.grays.gray7),
        const SizedBox(height: AppSpacing.x16),
        const Opacity(
          opacity: 0.42,
          child: _PollSection(
            title: '종료한 투표',
            items: _completedPolls,
            isActive: false,
          ),
        ),
      ],
    );
  }
}

class _PollSection extends StatelessWidget {
  const _PollSection({
    required this.title,
    required this.items,
    required this.isActive,
  });

  final String title;
  final List<_PollData> items;
  final bool isActive;

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final sectionColor = isActive ? colorScheme.primary : colorScheme.onSurface;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            SvgPicture.asset(
              _goodIconPath,
              width: 14,
              height: 14,
              colorFilter: ColorFilter.mode(sectionColor, BlendMode.srcIn),
            ),
            const SizedBox(width: AppSpacing.x4),
            Text(title, style: FontStyles.med12.copyWith(color: sectionColor)),
          ],
        ),
        const SizedBox(height: AppSpacing.x8),
        ...List.generate(items.length, (index) {
          return Padding(
            padding: EdgeInsets.only(
              bottom: index == items.length - 1 ? 0 : AppSpacing.x20,
            ),
            child: _PollListItem(item: items[index]),
          );
        }),
      ],
    );
  }
}

class _PollListItem extends StatelessWidget {
  const _PollListItem({required this.item});

  final _PollData item;

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          item.title,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: FontStyles.bold20.copyWith(color: colorScheme.onSurface),
        ),
        const SizedBox(height: AppSpacing.x4),
        Wrap(
          crossAxisAlignment: WrapCrossAlignment.center,
          spacing: AppSpacing.x4,
          children: [
            if (item.isUrgent)
              Text(
                '[종료 임박]',
                style: FontStyles.reg12.copyWith(color: colorScheme.primary),
              ),
            Text(
              item.dateText,
              style: FontStyles.reg12.copyWith(color: context.grays.gray4),
            ),
          ],
        ),
        const SizedBox(height: AppSpacing.x8),
        _PostMetaChip(
          firstIconPath: _goodIconPath,
          firstText: '${item.participantCount}명',
          secondIconPath: _chatIconPath,
          secondText: item.voteStatus,
          secondTextColor: item.isUrgent ? colorScheme.primary : null,
        ),
      ],
    );
  }
}

class _PollData {
  const _PollData({
    required this.title,
    required this.dateText,
    required this.participantCount,
    required this.voteStatus,
    this.isUrgent = false,
  });

  final String title;
  final String dateText;
  final int participantCount;
  final String voteStatus;
  final bool isUrgent;
}

// -----------------------------------------------------------------------------
// 밋잇
// -----------------------------------------------------------------------------

enum _MeetitMenuAction { delete }

class _MeetitContent extends StatelessWidget {
  const _MeetitContent();

  static const List<_MeetitData> _items = [
    _MeetitData(
      title: '4월 둘째주 합주',
      participantCount: 7,
      resultText: '2명 완료',
      hasCompletedResult: true,
    ),
    _MeetitData(
      title: '4월 첫째주 회식',
      participantCount: 6,
      resultText: '4명 완료',
      hasCompletedResult: true,
    ),
    _MeetitData(
      title: '합주',
      participantCount: 7,
      resultText: '미완료',
      hasCompletedResult: false,
    ),
  ];

  void _handleDelete(_MeetitData item) {
    // TODO: 삭제 확인 팝업 또는 삭제 API 연결
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: List.generate(_items.length, (index) {
        final item = _items[index];

        return Padding(
          padding: EdgeInsets.only(
            bottom: index == _items.length - 1 ? 0 : AppSpacing.x20,
          ),
          child: _MeetitListItem(
            item: item,
            onDelete: () => _handleDelete(item),
          ),
        );
      }),
    );
  }
}

class _MeetitListItem extends StatelessWidget {
  const _MeetitListItem({required this.item, required this.onDelete});

  final _MeetitData item;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                item.title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: FontStyles.bold20.copyWith(color: colorScheme.onSurface),
              ),
            ),
            PopupMenuButton<_MeetitMenuAction>(
              tooltip: '밋잇 메뉴',
              padding: EdgeInsets.zero,
              offset: const Offset(0, AppSpacing.x4),
              color: colorScheme.surface,
              elevation: 4,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(5),
                side: BorderSide(color: context.grays.gray7),
              ),
              onSelected: (action) {
                if (action == _MeetitMenuAction.delete) {
                  onDelete();
                }
              },
              itemBuilder: (context) {
                return [
                  PopupMenuItem<_MeetitMenuAction>(
                    value: _MeetitMenuAction.delete,
                    height: 40,
                    child: Row(
                      children: [
                        Icon(
                          Icons.check,
                          size: 18,
                          color: colorScheme.onSurface,
                        ),
                        const SizedBox(width: AppSpacing.x8),
                        Text(
                          '삭제하기',
                          style: FontStyles.med16.copyWith(
                            color: colorScheme.onSurface,
                          ),
                        ),
                      ],
                    ),
                  ),
                ];
              },
              icon: Icon(
                Icons.more_vert,
                size: 20,
                color: colorScheme.onSurface,
              ),
            ),
          ],
        ),
        const SizedBox(height: AppSpacing.x4),
        _PostMetaChip(
          firstIconPath: _goodIconPath,
          firstText: '${item.participantCount}명',
          secondIconPath: _chatIconPath,
          secondText: item.resultText,
          secondTextColor: item.hasCompletedResult
              ? colorScheme.primary
              : context.grays.gray5,
        ),
      ],
    );
  }
}

class _MeetitData {
  const _MeetitData({
    required this.title,
    required this.participantCount,
    required this.resultText,
    required this.hasCompletedResult,
  });

  final String title;
  final int participantCount;
  final String resultText;
  final bool hasCompletedResult;
}

// -----------------------------------------------------------------------------
// 공통 메타 정보 칩
// -----------------------------------------------------------------------------

class _PostMetaChip extends StatelessWidget {
  const _PostMetaChip({
    required this.firstIconPath,
    required this.firstText,
    required this.secondIconPath,
    required this.secondText,
    this.firstTextColor,
    this.secondTextColor,
  });

  final String firstIconPath;
  final String firstText;
  final String secondIconPath;
  final String secondText;
  final Color? firstTextColor;
  final Color? secondTextColor;

  @override
  Widget build(BuildContext context) {
    final iconColor = context.grays.gray3;
    final defaultTextColor = context.grays.gray4;

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.x8,
        vertical: AppSpacing.x4,
      ),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(5),
        color: context.grays.gray8,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          SvgPicture.asset(
            firstIconPath,
            width: 14,
            height: 14,
            colorFilter: ColorFilter.mode(iconColor, BlendMode.srcIn),
          ),
          const SizedBox(width: AppSpacing.x4),
          Text(
            firstText,
            style: FontStyles.med12.copyWith(
              color: firstTextColor ?? defaultTextColor,
            ),
          ),
          const SizedBox(width: AppSpacing.x8),
          SvgPicture.asset(
            secondIconPath,
            width: 14,
            height: 14,
            colorFilter: ColorFilter.mode(iconColor, BlendMode.srcIn),
          ),
          const SizedBox(width: AppSpacing.x4),
          Text(
            secondText,
            style: FontStyles.med12.copyWith(
              color: secondTextColor ?? defaultTextColor,
            ),
          ),
        ],
      ),
    );
  }
}
