import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:beatit_front_app/src/domain/auth/provider/reset_password_provider.dart';

import 'package:beatit_front_app/src/core/theme/app_spacing.dart';
import 'package:beatit_front_app/src/core/widgets/appbars/app_top_appbar.dart';
import 'package:beatit_front_app/src/core/widgets/buttons/app_button.dart';
import 'package:beatit_front_app/src/core/widgets/inputs/app_field_message.dart';
import 'package:beatit_front_app/src/core/widgets/inputs/app_text_field.dart';
import 'package:beatit_front_app/src/core/theme/app_fonts.dart';
import 'package:beatit_front_app/src/core/extensions/app_theme_extension.dart';
import 'package:beatit_front_app/src/domain/auth/widget/result_box.dart';

class VerifyPasswordPage extends ConsumerStatefulWidget {
  const VerifyPasswordPage({super.key});

  @override
  ConsumerState<VerifyPasswordPage> createState() => _VerifyPasswordPageState();
}

class _VerifyPasswordPageState extends ConsumerState<VerifyPasswordPage> {
  final idController = TextEditingController();
  final emailController = TextEditingController();
  final codeController = TextEditingController();

  bool get _canSubmit {
    return idController.text.isNotEmpty &&
        emailController.text.isNotEmpty &&
        codeController.text.isNotEmpty;
  }

  Future<void> _sendEmailCode() async {
    final success = await ref
        .read(resetPasswordProvider.notifier)
        .sendCode(
          email: emailController.text.trim(),
          identifier: idController.text.trim(),
        );
  }

  @override
  void dispose() {
    idController.dispose();
    emailController.dispose();
    codeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colors = theme.colorScheme;
    final state = ref.watch(resetPasswordProvider);

    return Scaffold(
      appBar: AppTopAppBar.backOnly(
        onBackPressed: () {
          Navigator.of(context).maybePop();
        },
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(
            vertical: AppSpacing.x24,
            horizontal: AppSpacing.x16,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '비밀번호 재설정',
                style: FontStyles.bold28.copyWith(color: colors.onSurface),
              ),
              const SizedBox(height: AppSpacing.x4),
              Text(
                '가입한 이메일을 통해 인증 후 아이디를 확인해주세요.',
                style: FontStyles.reg12.copyWith(
                  color: colors.onSurfaceVariant,
                ),
              ),
              const SizedBox(height: AppSpacing.x50),

              _RequiredLabel(
                text: '아이디',
                color: colors.onSurface,
                requiredColor: colors.primary,
              ),
              const SizedBox(height: AppSpacing.x8),
              AppTextField(
                hintText: '아이디',
                controller: idController,
                isError: state.emailError != null,
                onChanged: (_) {
                  ref
                      .read(resetPasswordProvider.notifier)
                      .onIdentifierChanged();
                  setState(() {});
                },
              ),
              if (state.emailError != null) ...[
                const SizedBox(height: AppSpacing.x4),
                AppFieldMessage(text: state.emailError!, isError: true),
              ],

              const SizedBox(height: AppSpacing.x20),

              Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Expanded(
                    child: AppTextField(
                      label: '이메일 인증',
                      hintText: '이메일',
                      controller: emailController,
                      keyboardType: TextInputType.emailAddress,
                      onChanged: (_) {
                        ref
                            .read(resetPasswordProvider.notifier)
                            .onEmailChanged();
                        setState(() {});
                      },
                    ),
                  ),
                  const SizedBox(width: AppSpacing.x10),
                  AppButton(
                    text: state.isSendingCode
                        ? '전송 중'
                        : state.isCodeSent
                        ? '재전송'
                        : '인증번호 발송',
                    width: ButtonWidth.medium,
                    height: ButtonHeight.small,
                    variant: ButtonVariant.black,
                    onPressed: _sendEmailCode,
                  ),
                ],
              ),
              if (state.isCodeSent) ...[
                const SizedBox(height: AppSpacing.x4),
                AppFieldMessage(
                  text: '인증 번호가 발송되었습니다. 3분 이내로 인증번호를 입력해주세요.',
                  color: colors.onSurfaceVariant,
                ),
              ],

              const SizedBox(height: AppSpacing.x10),

              Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Expanded(
                    child: AppTextField(
                      hintText: '인증번호',
                      keyboardType: TextInputType.emailAddress,
                      onChanged: (_) {},
                    ),
                  ),
                  const SizedBox(width: AppSpacing.x10),
                  AppButton(
                    text: '확인',
                    width: ButtonWidth.medium,
                    height: ButtonHeight.small,
                    variant: ButtonVariant.black,
                    onPressed: () {
                      //TODO: 인증번호와 email을 함께 api로 보내고, 인증번호가 맞는지 확인.

                      //TODO: 인증번호가 맞으면, 비밀번호 재설정 페이지 이동.
                    },
                  ),
                ],
              ),
              //FIXME: 인증번호가 맞는지/틀리는지에 따라 다른 값이 들어가야 함.
              if (_isEmailCodeSent) ...[
                const SizedBox(height: AppSpacing.x4),
                AppFieldMessage(
                  text: '인증번호가 일치하지 않습니다.',
                  color: context.brands.error,
                  isError: true,
                ),
                AppFieldMessage(
                  text: '인증번호 확인이 완료되었습니다.',
                  color: context.grays.gray1,
                  icon: 'assets/icons/check/check_round_green.svg',
                ),
              ],

              const SizedBox(height: AppSpacing.x20),
            ],
          ),
        ),
      ),
    );
  }
}

class _RequiredLabel extends StatelessWidget {
  const _RequiredLabel({
    required this.text,
    required this.color,
    required this.requiredColor,
  });

  final String text;
  final Color color;
  final Color requiredColor;

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: RichText(
        text: TextSpan(
          style: FontStyles.semi16.copyWith(color: color),
          children: [
            TextSpan(text: text),
            TextSpan(
              text: ' *',
              style: FontStyles.semi16.copyWith(color: requiredColor),
            ),
          ],
        ),
      ),
    );
  }
}

class _PasswordVisibilityButton extends StatelessWidget {
  const _PasswordVisibilityButton({
    required this.isVisible,
    required this.onTap,
  });

  final bool isVisible;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: SizedBox(
        width: 24,
        height: 24,
        child: isVisible
            ? SvgPicture.asset('assets/icons/auth/eye_off.svg')
            : SvgPicture.asset('assets/icons/auth/eye_on.svg'),
      ),
    );
  }
}
