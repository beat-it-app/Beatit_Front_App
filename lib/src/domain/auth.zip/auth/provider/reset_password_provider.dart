import 'package:beatit_front_app/src/domain/auth/api/auth_api.dart';
import 'package:beatit_front_app/src/domain/auth/provider/auth_api_provider.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final resetPasswordProvider =
    NotifierProvider.autoDispose<ResetPasswordNotifier, ResetPasswordState>(
      ResetPasswordNotifier.new,
    );

class ResetPasswordState {
  const ResetPasswordState({
    this.isSendingCode = false,
    this.isVerifyingCode = false,
    this.isResettingPassword = false,
    this.isCodeSent = false,
    this.password,
    this.identifier,
    this.emailError,
    this.codeError,
  });

  final bool isSendingCode;
  final bool isVerifyingCode;
  final bool isResettingPassword;
  final bool isCodeSent;
  final String? password;
  final String? identifier;
  final String? emailError;
  final String? codeError;

  bool get isResetPassword => password?.isNotEmpty == true;
  bool get isLoading => isSendingCode || isVerifyingCode || isResettingPassword;

  ResetPasswordState copyWith({
    bool? isSendingCode,
    bool? isVerifyingCode,
    bool? isCodeSent,
    bool? isVerified,
    String? password,
    String? identifier,
    String? emailError,
    String? codeError,
    bool clearPassword = false,
    bool clearIdentifier = false,
    bool clearEmailError = false,
    bool clearCodeError = false,
  }) {
    return ResetPasswordState(
      isSendingCode: isSendingCode ?? this.isSendingCode,
      isVerifyingCode: isVerifyingCode ?? this.isVerifyingCode,
      isCodeSent: isCodeSent ?? this.isCodeSent,
      password: clearPassword ? null : password ?? this.password,
      identifier: clearIdentifier ? null : identifier ?? this.identifier,
      emailError: clearEmailError ? null : emailError ?? this.emailError,
      codeError: clearCodeError ? null : codeError ?? this.codeError,
    );
  }
}

class ResetPasswordNotifier extends Notifier<ResetPasswordState> {
  @override
  ResetPasswordState build() {
    return const ResetPasswordState();
  }

  Future<bool> sendCode({
    required String email,
    required String identifier,
  }) async {
    state = state.copyWith(
      isSendingCode: true,
      isCodeSent: false,
      clearPassword: true,
      clearIdentifier: true,
      clearEmailError: true,
      clearCodeError: true,
    );

    try {
      final authApi = ref.read(authApiProvider);

      await authApi.sendResetPasswordCode(email: email, identifier: identifier);

      state.copyWith(isSendingCode: false, isCodeSent: true);

      return true;
    } catch (error) {
      state = state.copyWith(
        isSendingCode: false,
        emailError: error.toString(),
      );

      return false;
    }
  }

  Future<bool> verifyCode({
    required String identifier,
    required String email,
    required String code,
  }) async {
    if (!state.isCodeSent) {
      return false;
    }

    state = state.copyWith(
      isVerifyingCode: true,
      clearPassword: true,
      clearCodeError: true,
    );

    try {
      final authApi = ref.read(authApiProvider);

      await authApi.verifyResetPasswordCode(
        identifier: identifier,
        email: email,
        code: code,
      );

      state = state.copyWith(isVerifyingCode: false, isVerified: true);

      return true;
    } catch (error) {
      state = state.copyWith(
        isVerifyingCode: false,
        codeError: _getErrorMessage(error),
      );

      return false;
    }
  }

  Future<bool> resetPassword({
    required String identifier,
    required String email,
    required String newPassword,
  }) async {
    state = state.copyWith(
      isVerifyingCode: true,
      clearPassword: true,
      clearCodeError: true,
    );

    try {
      final authApi = ref.read(authApiProvider);

      final result = await authApi.resetPassword(
        identifier: identifier,
        email: email,
        newPassword: newPassword,
      );

      state = state.copyWith(isVerifyingCode: false, password: result.password);

      return true;
    } catch (error) {
      state = state.copyWith(
        isVerifyingCode: false,
        codeError: _getErrorMessage(error),
      );

      return false;
    }
  }

  void onEmailChanged() {
    if (!state.isCodeSent &&
        state.emailError == null &&
        state.codeError == null &&
        state.identifier == null) {
      return;
    }

    state = const ResetPasswordState();
  }

  void onCodeChanged() {
    if (state.codeError == null) {
      return;
    }

    state = state.copyWith(clearCodeError: true);
  }

  void reset() {
    state = const ResetPasswordState();
  }

  String _getErrorMessage(Object error) {
    if (error is AuthApiException) {
      return error.message;
    }
    return '요청 처리 중 오류가 발생했습니다.';
  }
}
